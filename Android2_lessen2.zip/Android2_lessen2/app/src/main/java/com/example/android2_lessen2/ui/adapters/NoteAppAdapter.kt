package com.example.android2_lessen2.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.graphics.toColorInt
import androidx.recyclerview.widget.RecyclerView
import com.example.android2_lessen2.databinding.ItemNoteAppBinding
import com.example.android2_lessen2.models.NoteModel

class NoteAppAdapter(
    val onItemClick: (NoteModel) -> Unit
) : RecyclerView.Adapter<NoteAppAdapter.NoteViewHolder>() {

    private var list: List<NoteModel> = ArrayList()

    fun setList(list: List<NoteModel>) {
        this.list = list
        notifyDataSetChanged()
    }

    inner class NoteViewHolder(private val binding: ItemNoteAppBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            itemView.setOnClickListener {
                getItemId(absoluteAdapterPosition).apply {
                    onItemClick
                }
            }
        }

        fun onBind(noteModel: NoteModel) = with(binding) {
            titleTxt.text = noteModel.title
            descriptionTxt.text = noteModel.description
            textData.text = noteModel.data
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        return NoteViewHolder(
            ItemNoteAppBinding.inflate(
                LayoutInflater.from(
                    parent.context
                ), parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }
}