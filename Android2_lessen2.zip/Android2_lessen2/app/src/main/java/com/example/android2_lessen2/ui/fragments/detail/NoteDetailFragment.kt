package com.example.android2_lessen2.ui.fragments.detail

import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Note
import android.text.Editable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.android2_lessen2.App
import com.example.android2_lessen2.databinding.FragmentNoteDetailBinding
import com.example.android2_lessen2.extensions.getBackStateData
import com.example.android2_lessen2.extensions.setBacStackData
import com.example.android2_lessen2.models.NoteModel

class NoteDetailFragment : Fragment() {

    private lateinit var binding: FragmentNoteDetailBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentNoteDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sendData()
        fragmentUp()
    }

    private fun fragmentUp() {
        binding.arrowLeft.setOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun sendData() = with(binding) {
        enter.setOnClickListener {
            if (etTex1.text.isNotEmpty() || etTex2.text.isNotEmpty()) {
                val title = etTex1.text.toString()
                val direction = etTex2.text.toString()
                val data = tvMay.text.toString()
                App().getInstance()?.noteDao()?.insert(NoteModel(title,direction,data))
                findNavController().navigateUp()
            }
        }

//        getBackStateData<NoteModel>("anime") {
//            title = it.title
//            direction = it.description
//            time = it.time
//            color = it.color
//            binding.etTex1.text = title as Editable?
//            binding.etTex2.text = direction as Editable?
//        }
    }
}